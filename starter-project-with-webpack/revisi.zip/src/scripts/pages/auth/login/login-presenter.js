import { putAccessToken } from '../../../utils/auth';

export class LoginPresenter {
  constructor(modelFn, view) {
    this.modelFn = modelFn;
    this.view = view;
  }

  async login(email, password) {
    try {
      this.view.showLoading();

      const { loginResult } = await this.modelFn(email, password);

      if (!loginResult?.token) {
        throw new Error('Token tidak valid dari server.');
      }

      putAccessToken(loginResult.token);

      this.view.showSuccess(loginResult.name);
      window.location.hash = '#/';
    } catch (error) {
      this.view.showError(error);
    }
  }
}
